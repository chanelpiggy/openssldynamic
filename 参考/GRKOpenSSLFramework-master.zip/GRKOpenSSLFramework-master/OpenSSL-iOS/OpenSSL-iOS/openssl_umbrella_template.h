//
//  openssl.h
//  OpenSSL-iOS
//
//  Created by @levigroker @DATE@.
//  Copyright © @YEAR@ @levigroker. All rights reserved.
//

#ifndef openssl_h
#define openssl_h

#ifdef __OBJC__

#import <Foundation/Foundation.h>

//! Project version number for OpenSSL-iOS.
FOUNDATION_EXPORT double OpenSSL_iOSVersionNumber;

//! Project version string for OpenSSL-iOS.
FOUNDATION_EXPORT const unsigned char OpenSSL_iOSVersionString[];

#endif

@GENERATED_CONTENT@

#endif /* openssl_h */
