//
//  openssl2.h
//  openssl2
//
//  Created by CHANEL on 2021/2/20.
//  Copyright © 2021 levigroker. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for openssl2.
FOUNDATION_EXPORT double openssl2VersionNumber;

//! Project version string for openssl2.
FOUNDATION_EXPORT const unsigned char openssl2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <openssl2/PublicHeader.h>


