//
//  openssl.h
//  OpenSSL-macOS
//
//  Created by @levigroker @DATE@.
//  Copyright © @YEAR@ @levigroker. All rights reserved.
//

#ifndef openssl_h
#define openssl_h

#ifdef __OBJC__

#import <Cocoa/Cocoa.h>

//! Project version number for OpenSSL-macOS.
FOUNDATION_EXPORT double OpenSSL_macOSVersionNumber;

//! Project version string for OpenSSL-macOS.
FOUNDATION_EXPORT const unsigned char OpenSSL_macOSVersionString[];

#endif

@GENERATED_CONTENT@

#endif /* openssl_h */
